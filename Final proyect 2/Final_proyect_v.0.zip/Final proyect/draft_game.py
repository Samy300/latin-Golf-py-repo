

import pygame
import sys

# Inicializar el módulo de mixer
pygame.mixer.init()
# Inicia Pygame
pygame.init()


# Colores
YELLOW = (255, 255, 0)
GREEN = (0, 128, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


# Configurar la pantalla
screen_width, screen_height = 1345, 760
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Let´s Golf")
background_image = pygame.image.load("Final proyect/Imagenes/fonfr_draft.jpg")  # Imagen de fondo
background_image = pygame.transform.scale(background_image, (1385, 760))
# Fuentes
title_font = pygame.font.Font("Final proyect/fonts/Caveat-VariableFont_wght.ttf", 150)  # Título
button_font = pygame.font.Font("Final proyect/fonts/BagelFatOne-Regular.ttf", 50)  # Botones
# Cargar imagen de botón
play_button_image = pygame.image.load("Final proyect/Imagenes/boton_play.png").convert_alpha()  
levels_button_image = pygame.image.load("Final proyect/Imagenes/botones_levels_credits.png").convert_alpha()
credits_button_image = pygame.image.load("Final proyect/Imagenes/botones_levels_credits.png").convert_alpha()
# Cambia a las dimensiones deseadas
play_button_image = pygame.transform.scale(play_button_image, (190, 70))  
levels_button_image = pygame.transform.scale(levels_button_image, (285, 135))  
credits_button_image = pygame.transform.scale(credits_button_image, (300, 135)) 
# Título del juego
title_text = title_font.render("Let's Golf", True, YELLOW)
# Cargar la música de fondo
pygame.mixer.music.load("Final proyect/musica/cancion__menu_1.mp3") 
pygame.mixer.music.set_volume(0.5)  # Volumen
pygame.mixer.music.play(-1)  # Reproduce en bucle
# Cargar el logo
logo_image = pygame.image.load("Final proyect/Imagenes/latin_mafia_logo.png").convert_alpha()
# Escalar el logo si es necesario
logo_image = pygame.transform.scale(logo_image, (3000, 900))  # Ajusta el tamaño deseado

"""
# Playlist
def play_next_song():
    global current_song_index
    pygame.mixer.music.load(playlist[current_song_index])  # Cargar la canción actual
    pygame.mixer.music.play()  # Reproducir la canción
    current_song_index = (current_song_index + 1) % len(playlist)  # Avanzar al siguiente índice en bucle

# Configurar el índice inicial y reproducir la primera canción
current_song_index = 0
play_next_song()

# Configurar evento para detectar cuando una canción termina
pygame.mixer.music.set_endevent(pygame.USEREVENT + 1)

"""

def intro_screen():
    # Cargar el logo
    logo_image = pygame.image.load("Final proyect/Imagenes/latin_mafia_logo.png").convert_alpha()
    logo_image = pygame.transform.scale(logo_image, (3000, 900))  # Ajusta el tamaño del logo

    # Centrar el logo
    logo_rect = logo_image.get_rect(center=(screen_width // 2, screen_height // 2))
    
    # Variable opacidad
    opacity = 255
    fade_out = True  # Controla si la imagen se desvanece

    while True:
        screen.fill(BLACK)  # Fondo negro para la pantalla de carga

        # Ajustar opacidad del logo
        logo_image.set_alpha(opacity)
        screen.blit(logo_image, logo_rect)  # Dibujar el logo en el centro de la pantalla

        # Controlar el desvanecimiento
        if fade_out:
            opacity -= 5  # Reducir opacidad
            if opacity <= 0:
                break  # Salir del bucle cuando esté completamente desvanecido
        else:
            opacity += 5  # Aumentar opacidad

        pygame.display.flip()  # Actualizar pantalla
        pygame.time.delay(65)  # Controla la velocidad del desvanecimiento

        # Procesar eventos para permitir el cierre de la ventana
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

# Borde solo para el titulo porque me equivoque :)
def render_text_with_border(text, font, border_color, border_width, offset=(0, 0)):
    # Renderizar el texto del borde
    text_surface = font.render(text, True, border_color)
    text_rect = text_surface.get_rect()

    for dx in range(-border_width, border_width + 1):
        for dy in range(-border_width, border_width + 1): 
            if dx != 0 or dy != 0:  
                screen.blit(text_surface, (text_rect.x + dx + offset[0], text_rect.y + dy + offset[1]))

# Bordes para los textos con botones
def render_botton_text_with_border(text, font, border_color, border_width, x, y):
    # Renderizar el texto del borde
    text_surface = font.render(text, True, border_color)
    text_rect = text_surface.get_rect(center=(x, y))
    

    for dx in range(-border_width, border_width + 1):
        for dy in range(-border_width, border_width + 1): 
            if dx != 0 or dy != 0:
                screen.blit(text_surface, (text_rect.x + dx, text_rect.y + dy))


# Función para poner botones
def draw_button(text, x, y):
    button_surface = button_font.render(text, True, (WHITE))
    button_rect = button_surface.get_rect(center=(x, y))
    render_botton_text_with_border(text, button_font, (BLACK), 2, x + 5, y + 5)
   
    
    # Obtener la posición del mouse
    mouse_x, mouse_y = pygame.mouse.get_pos()
    
    # Comprobar si el mouse está sobre el botón
    if button_rect.collidepoint(mouse_x, mouse_y):
        # Desplazar el texto
        offset_x = 5  
        offset_y = -5 
    else:
        
        offset_x = 0
        offset_y = 0

    # Renderizar el texto con el desplazamiento
    text_rect = button_surface.get_rect(center=(x + offset_x, y - offset_y))
    screen.blit(button_surface, text_rect)

    return button_rect

def draw_image_button(image, x, y):
    # Acomodar los botones
    button_rect = image.get_rect(center=(x, y))  # Obtiene el rectángulo de la imagen para centrar la imagen
    screen.blit(image, button_rect)  # Dibuja la imagen

    
    return button_rect  # Detección de clics

# Llamar a la pantalla de carga antes del menú principal
intro_screen()


def main_menu():

    # Cerrar la ventana sin forzarla
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()


            """ # En caso de uso de una playlist
                for event in pygame.event.get():
                  if event.type == pygame.QUIT:
                     pygame.quit()
                     sys.exit()
                  elif event.type == pygame.USEREVENT + 1:  # Detectar cuando termina una canción
                   play_next_song()  # Reproducir la siguiente canción

                    """
            
            

        screen.blit(background_image, (-40, 0))  # Dibujar fondo 
        render_text_with_border("Let's Golf", title_font, (BLACK), 2, offset=(425, 60))  # Borde negro
        screen.blit(title_text, (screen_width // 2 - title_text.get_width() // 2, 60))  # Centrar el título
        
        
 
        # Colocar las imágenes para los botones
        play_button_rect = draw_image_button(play_button_image, screen_width // 2, screen_height // 2 - 50)
        levels_button_rect = draw_image_button(levels_button_image, screen_width // 2 - 3, screen_height // 2 + 60)
        credits_button_rect = draw_image_button(credits_button_image, screen_width // 2, screen_height // 2 + 170)
        
        
        # Dibujar el texto de los botones
        play_button = draw_button("PLAY", screen_width // 2, screen_height // 2 - 60)
        levels_button = draw_button("LEVELS", screen_width // 2, screen_height // 2 + 50)
        credits_button = draw_button("CREDITS", screen_width // 2, screen_height // 2 + 160)
        

        pygame.display.flip()  # Actualizar la pantalla

        # Comprobar si se hace clic en un botón
        mouse_x, mouse_y = pygame.mouse.get_pos()
        if pygame.mouse.get_pressed()[0]:  # Si se hace clic
            if play_button.collidepoint(mouse_x, mouse_y):
                print("Iniciar juego")
            elif levels_button.collidepoint(mouse_x, mouse_y):
                print("Seleccionar nivel")
            elif credits_button.collidepoint(mouse_x, mouse_y):
                credits_screen()

def play_button_function():

    # Falta trabajar en ello
    pygame.display.flip()

def levels_menu():

    # Falta trabajar en ello
    pygame.display.flip()

def credits_screen():
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:  # Regresar al menú si presionan "ESC"
                    running = False

        # Colorear el fondo
        screen.fill(BLACK)

        # Dibujar el logo
        logo_rect = logo_image.get_rect(center=(660, 400))  # Centrar el logo en la parte superior
        screen.blit(logo_image, logo_rect)
        
        # Texto de créditos
        credits_font = pygame.font.Font("Final proyect/fonts/BagelFatOne-Regular.ttf", 40)
        credits_text = credits_font.render("CREDITS", True, WHITE)
        screen.blit(credits_text, (screen_width // 2 - credits_text.get_width() // 2, 50))

        # Bordes de los creditos
        render_text_with_border("Developer: LatinMafia team", credits_font, BLACK, 2, offset=(418, 150))
        render_text_with_border("Lead Programmer: [Nombre]", credits_font, BLACK, 2, offset=(410, 200))
        render_text_with_border("Game Designer: [Nombre]", credits_font, BLACK, 2, offset=(436, 250))
        render_text_with_border("Art Director: [Nombre]", credits_font, BLACK, 2, offset=(458, 300))
        render_text_with_border("Sound Design: [Nombre]", credits_font, BLACK, 2, offset=(450, 350))
        render_text_with_border("Voice Acting: [Nombre]", credits_font, BLACK, 2, offset=(458, 400))
        render_text_with_border("Quality Assurance: [Nombre]", credits_font, BLACK, 2, offset=(405, 450))
        render_text_with_border("Level Designer: [Nombre]", credits_font, BLACK, 2, offset=(440, 500))
        

        # Listar nombres y roles (puedes personalizar estos)
        team_text = [
            "Developer: LatinMafia team",
            "Lead Programmer: [Nombre]",
            "Game Designer: [Nombre]",
            "Art Director: [Nombre]",
            "Sound Design: [Nombre]",
            "Voice Acting: [Nombre]",
            "Quality Assurance: [Nombre]",
            "Level Designer: [Nombre]",
        ]

        
        for i, line in enumerate(team_text):
            line_surface = credits_font.render(line, True, WHITE)
            screen.blit(line_surface, (screen_width // 2 - line_surface.get_width() // 2, 150 + i * 50))

        
            
        

        # Actualizar pantalla
        pygame.display.flip()

# Iniciar el menú
main_menu()


